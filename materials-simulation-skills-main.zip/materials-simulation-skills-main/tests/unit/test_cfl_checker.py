import unittest

from tests.unit._utils import load_module


class TestCflChecker(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_module(
            "cfl_checker",
            "skills/core-numerical/numerical-stability/scripts/cfl_checker.py",
        )

    def test_explicit_stable(self):
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.01,
            velocity=1.0,
            diffusivity=0.1,
            reaction_rate=1.0,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertTrue(result["stable"])
        self.assertAlmostEqual(result["metrics"]["cfl"], 0.1, places=6)
        self.assertAlmostEqual(result["metrics"]["fourier"], 0.1, places=6)
        self.assertAlmostEqual(result["recommended_dt"], 1.0 / 31.0, places=6)

    def test_explicit_unstable(self):
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.1,
            velocity=2.0,
            diffusivity=None,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertFalse(result["stable"])
        self.assertAlmostEqual(result["recommended_dt"], 0.05, places=6)

    def test_reaction_unstable(self):
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.2,
            velocity=None,
            diffusivity=None,
            reaction_rate=10.0,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertFalse(result["stable"])
        self.assertAlmostEqual(result["metrics"]["reaction"], 2.0, places=6)
        self.assertAlmostEqual(result["recommended_dt"], 0.1, places=6)

    def test_no_criteria(self):
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.01,
            velocity=None,
            diffusivity=None,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertIsNone(result["stable"])
        self.assertIn("No stability criteria applied", result["notes"][0])

    def test_criteria_applied_advection_only(self):
        result = self.mod.compute_cfl(
            dx=0.2,
            dt=0.1,
            velocity=0.5,
            diffusivity=None,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertIn("advection", result["criteria_applied"])
        self.assertNotIn("diffusion", result["criteria_applied"])

    def test_custom_limits(self):
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.1,
            velocity=1.0,
            diffusivity=1.0,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=0.2,
            diffusion_limit=0.1,
            reaction_limit=1.0,
            safety=1.0,
        )
        self.assertAlmostEqual(result["limits"]["advection_limit"], 0.2, places=6)
        self.assertAlmostEqual(result["limits"]["diffusion_limit"], 0.1, places=6)
        self.assertFalse(result["stable"])

    def test_invalid_dimensions(self):
        with self.assertRaises(ValueError):
            self.mod.compute_cfl(
                dx=0.1,
                dt=0.01,
                velocity=1.0,
                diffusivity=0.1,
                reaction_rate=None,
                dimensions=0,
                scheme="explicit",
                advection_limit=None,
                diffusion_limit=None,
                reaction_limit=None,
                safety=1.0,
            )

    def test_invalid_safety(self):
        with self.assertRaises(ValueError):
            self.mod.compute_cfl(
                dx=0.1,
                dt=0.01,
                velocity=1.0,
                diffusivity=0.1,
                reaction_rate=None,
                dimensions=1,
                scheme="explicit",
                advection_limit=None,
                diffusion_limit=None,
                reaction_limit=None,
                safety=0.0,
            )

    def test_negative_diffusivity_produces_warning(self):
        """Negative diffusivity should produce a warning note, not silent abs()."""
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.01,
            velocity=None,
            diffusivity=-0.1,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        # Should still compute with abs(diffusivity)
        self.assertIsNotNone(result["metrics"]["fourier"])
        # But must include a warning note
        notes = result["notes"]
        self.assertTrue(
            any("Negative diffusivity" in n for n in notes),
            f"Expected negative diffusivity warning in notes: {notes}",
        )

    def test_negative_velocity_produces_warning(self):
        """Negative velocity should produce a warning note."""
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.01,
            velocity=-1.0,
            diffusivity=None,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        notes = result["notes"]
        self.assertTrue(
            any("Negative velocity" in n for n in notes),
            f"Expected negative velocity warning in notes: {notes}",
        )

    def test_diffusion_limit_dimensions(self):
        result = self.mod.compute_cfl(
            dx=0.1,
            dt=0.005,
            velocity=None,
            diffusivity=0.2,
            reaction_rate=None,
            dimensions=2,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertAlmostEqual(result["limits"]["diffusion_limit"], 0.25, places=6)
        self.assertTrue(result["stable"])

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            self.mod.compute_cfl(
                dx=0.0,
                dt=0.01,
                velocity=1.0,
                diffusivity=0.1,
                reaction_rate=None,
                dimensions=1,
                scheme="explicit",
                advection_limit=None,
                diffusion_limit=None,
                reaction_limit=None,
                safety=1.0,
            )

    def test_dimensions_whitelist_rejects_four(self):
        """Regression (F3 security): --dimensions outside {1,2,3} must raise."""
        with self.assertRaises(ValueError):
            self.mod.compute_cfl(
                dx=0.01,
                dt=1e-4,
                velocity=None,
                diffusivity=1e-3,
                reaction_rate=None,
                dimensions=4,
                scheme="explicit",
                advection_limit=None,
                diffusion_limit=None,
                reaction_limit=None,
                safety=1.0,
            )

    def test_non_finite_dx_raises(self):
        """Security: non-finite dx must raise, not propagate inf/nan."""
        with self.assertRaises(ValueError):
            self.mod.compute_cfl(
                dx=float("inf"),
                dt=1e-4,
                velocity=None,
                diffusivity=1e-3,
                reaction_rate=None,
                dimensions=1,
                scheme="explicit",
                advection_limit=None,
                diffusion_limit=None,
                reaction_limit=None,
                safety=1.0,
            )

    def test_non_finite_diffusivity_raises(self):
        with self.assertRaises(ValueError):
            self.mod.compute_cfl(
                dx=0.01,
                dt=1e-4,
                velocity=None,
                diffusivity=float("nan"),
                reaction_rate=None,
                dimensions=1,
                scheme="explicit",
                advection_limit=None,
                diffusion_limit=None,
                reaction_limit=None,
                safety=1.0,
            )

    def test_phase_field_example_unstable(self):
        """Regression (F1): the SKILL.md worked example (D=1, dt=1e-4, dx=0.01,
        2D) must report Fo=1.0, unstable, with recommended_dt=2.5e-5."""
        result = self.mod.compute_cfl(
            dx=0.01,
            dt=1e-4,
            velocity=None,
            diffusivity=1.0,
            reaction_rate=None,
            dimensions=2,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertAlmostEqual(result["metrics"]["fourier"], 1.0, places=9)
        self.assertAlmostEqual(result["limits"]["diffusion_limit"], 0.25, places=9)
        self.assertFalse(result["stable"])
        self.assertAlmostEqual(result["recommended_dt"], 2.5e-5, places=12)

    def test_eval_case1_fourier_value(self):
        """Regression (F2): eval case 1 inputs give Fo=1e-4 and stable=True."""
        result = self.mod.compute_cfl(
            dx=0.01,
            dt=0.001,
            velocity=None,
            diffusivity=1e-5,
            reaction_rate=None,
            dimensions=1,
            scheme="explicit",
            advection_limit=None,
            diffusion_limit=None,
            reaction_limit=None,
            safety=1.0,
        )
        self.assertAlmostEqual(result["metrics"]["fourier"], 1e-4, places=9)
        self.assertTrue(result["stable"])


if __name__ == "__main__":
    unittest.main()
