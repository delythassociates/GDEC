"""
GDEC Automated Test Suite.
"""
